package com.pfe.parking_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
