package com.pfe.parking_app.model;


import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;


@Entity
public class User extends Personne{

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Reservation> reservations;

    public User(String cni, String nom, String prenom,
                 String tel, String email, String motdepasse) {
        super(cni, nom, prenom, tel, email, motdepasse);
    }

    public User(){
        
    }

    //Getters et Setters
    public List<Reservation> getReservations() {
        return reservations;
    }

    public void setReservations(List<Reservation> reservations) {
        this.reservations = reservations;
    }

    

}
