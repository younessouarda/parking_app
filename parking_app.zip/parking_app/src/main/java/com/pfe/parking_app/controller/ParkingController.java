package com.pfe.parking_app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pfe.parking_app.exception.ParkingNotFoundException;
import com.pfe.parking_app.model.Parking;
import com.pfe.parking_app.repository.ParkingRepository;







@RestController
public class ParkingController {

    @Autowired
    private ParkingRepository parkingRepository;

    //To create a new parking
    @PostMapping("/addparking")
    Parking addParking(@RequestBody Parking parking) {
        return parkingRepository.save(parking);
    }

    //To get all parkings
    @GetMapping("/getparkings")
    public List<Parking> getAllParkings() {
        return parkingRepository.findAll();
    }

    //To get a parking by name
    @GetMapping("/getparking/{nom}")
    public Parking getParking(@PathVariable String nom) {
        return parkingRepository.findByNom(nom)
            .orElseThrow(() -> new ParkingNotFoundException(nom));
    }


    //To update a parking
    @PutMapping("updateparking/{nom}")
    public Parking updateParking(@RequestBody Parking newparking, @PathVariable String nom){

        return parkingRepository.findByNom(nom)
        .map(parking ->{
            parking.setNom(newparking.getNom());
            parking.setLongitude(newparking.getLongitude());
            parking.setLatitude(newparking.getLatitude());
            parking.setCapacite(newparking.getCapacite());
            parking.setTarif(newparking.getTarif());

            return parkingRepository.save(parking);

        }).orElseThrow(()-> new ParkingNotFoundException(nom));
    }

    //To delete a parking
    @DeleteMapping("/deleteparking/{nom}")
    public String deleteParking(@PathVariable String nom){
        //find the parking by its name
        Optional<Parking> parking = parkingRepository.findByNom(nom);

        if(parking.isPresent()){
            Long id = parking.get().getId();
            parkingRepository.deleteById(id);

            return "Parking with the name: "+nom+" has been deleted!";
        }

        else{
            throw new ParkingNotFoundException(nom);
        }
    }
    
    
}
