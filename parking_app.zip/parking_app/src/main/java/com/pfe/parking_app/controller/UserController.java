package com.pfe.parking_app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pfe.parking_app.exception.UserNotFoundException;
import com.pfe.parking_app.model.User;
import com.pfe.parking_app.repository.UserRepository;

@RestController
public class UserController {

    @Autowired
    private UserRepository userRepository;

    //To create a new user
    @PostMapping("/adduser")
    User addAutomobilsite(@RequestBody User user) {
        return userRepository.save(user);
    }

    //To get all the users
    @GetMapping("/getusers")
    java.util.List<User> getAllUsers() {
        return userRepository.findAll();
    }

    //To get a user by his cni
    @GetMapping("/getuser/{cni}")
    User getUserByCni(@PathVariable String cni) {
        return userRepository.findByCni(cni)
        .orElseThrow(()-> new UserNotFoundException(cni)); 
    }

    @PutMapping("updateuser/{cni}")
    User updateUser(@RequestBody User newUser,@PathVariable String cni){

        return userRepository.findByCni(cni)
            .map(user ->{
                user.setCni(newUser.getCni());
                user.setNom(newUser.getNom());
                user.setPrenom(newUser.getPrenom());
                user.setTel(newUser.getTel());
                user.setEmail(newUser.getEmail());
                user.setMotdepasse(newUser.getMotdepasse());
               
                return userRepository.save(user);
            }).orElseThrow(()-> new UserNotFoundException(cni));

    }

    @DeleteMapping("/deleteuser/{cni}")
    String deleteUser(@PathVariable String cni) {
        // Find the user by cni
        java.util.Optional<User> user = userRepository.findByCni(cni);
        
        if (user.isPresent()) {
            // Get the user's ID
            Long id = user.get().getId();
            
            // Delete the user by ID
            userRepository.deleteById(id);
            
            return "User with the cni " + cni + " has been deleted!";
        }else{
            throw new UserNotFoundException(cni);
        }
    }
    
}


