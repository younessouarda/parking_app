package com.pfe.parking_app.exception;

public class UserNotFoundException extends RuntimeException {

    public UserNotFoundException(String cni) {
        super("Could not find the User with the CNI: " + cni);
    }
}
