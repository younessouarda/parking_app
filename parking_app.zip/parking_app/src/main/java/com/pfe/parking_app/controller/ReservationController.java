package com.pfe.parking_app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pfe.parking_app.exception.ReservationNoutFoundException;
import com.pfe.parking_app.model.Reservation;
import com.pfe.parking_app.repository.ReservationRepository;

@RestController
public class ReservationController {

    @Autowired
    private ReservationRepository reservationRepository;

    //To add a new reservation
    @PostMapping("/addreservation")
    public Reservation addReservation(@RequestBody Reservation reservation){
        return reservationRepository.save(reservation);
    }

    //To get all reservations
    @GetMapping("/getreservations")
    public List<Reservation> getAllReservation(){
        return reservationRepository.findAll();
    }

    //To get all the reservations by the name of the user

    //To get all the reservation of a user by etat


    //To get a reservation by id
    @GetMapping("/getreservation/{id}")
    public Reservation getReservation(@PathVariable Long id){
        return reservationRepository.findById(id)
        .orElseThrow(()-> new ReservationNoutFoundException(id));
    }

    //To update a reservation by id
    @PutMapping("/updatereservation/{id}")
    public Reservation updateReservation(@RequestBody Reservation newreservation, @PathVariable Long id){
        return reservationRepository.findById(id)
        .map(reservation ->{
            reservation.setDateReservation(newreservation.getDateReservation());
            reservation.setHeureDebut(newreservation.getHeureDebut());
            reservation.setHeureDebut(newreservation.getHeureFin());
            reservation.setNomVehicule(newreservation.getNomVehicule());
            reservation.setMatricule(newreservation.getMatricule());

            return reservationRepository.save(reservation);
        }).orElseThrow(()-> new ReservationNoutFoundException(id));
    }

    //To delete a reservation by its id
    @DeleteMapping("/deletereservation/{id}")
    public String deleteReservation(@PathVariable Long id){
        if(reservationRepository.findById(id).isPresent()){
            reservationRepository.deleteById(id);
            return "The reservation with the id : "+id+"has been deleted";
        }
        else{
            throw new ReservationNoutFoundException(id);
        }
        
        
    }
}
