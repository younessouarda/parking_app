package com.pfe.parking_app.model;

import jakarta.persistence.Entity;

@Entity
public class Admin extends Personne {

    public Admin(String cni, String nom, String prenom,
                 String tel, String email, String motdepasse) {
        super(cni, nom, prenom, tel, email, motdepasse);
    }

    public Admin(){
        
    }

}
