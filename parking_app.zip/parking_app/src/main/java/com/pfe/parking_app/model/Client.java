package com.pfe.parking_app.model;

import jakarta.persistence.Entity;

@Entity
public class Client extends Personne {
    private String adresse;
    private String nomEntreprise;
    

    public Client(String cni, String nom, String prenom, String tel,
            String email, String motdepasse, String adresse,
            String nomEntreprise) 
        {

        super(cni, nom, prenom, tel, email, motdepasse);
        this.adresse = adresse;
        this.nomEntreprise = nomEntreprise;

    }

    public Client() {
       
    }
    
    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }


    public String getNomEntreprise() {
        return nomEntreprise;
    }


    public void setNomEntreprise(String nomEntreprise) {
        this.nomEntreprise = nomEntreprise;
    }

}
