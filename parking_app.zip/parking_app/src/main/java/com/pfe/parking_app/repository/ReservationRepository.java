package com.pfe.parking_app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pfe.parking_app.model.Reservation;

public interface ReservationRepository extends JpaRepository<Reservation, Long>{

}
