package com.pfe.parking_app.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Parking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nom;
    private Double longitude;
    private Double latitude;
    private int capacite;
    private Double tarif;

    @OneToMany(mappedBy = "parking", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Emplacement> emplacements;

    //Constructeur
    public Parking(String nom, Double longitude, Double latitude, int capacite, Double tarif) {
        this.nom = nom;
        this.longitude = longitude;
        this.latitude = latitude;
        this.capacite = capacite;
        this.tarif = tarif;
    }

    public Parking(){

    }


    //Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public Double getTarif() {
        return tarif;
    }

    public void setTarif(Double tarif) {
        this.tarif = tarif;
    }

    public List<Emplacement> getEmplacements() {
        return emplacements;
    }

    public void setEmplacements(List<Emplacement> emplacements) {
        this.emplacements = emplacements;
    }
    
    //Methods
    /*public void addEmplacement(Emplacement emplacement) {
        if (emplacements.size() < capacite) {
            emplacements.add(emplacement);
            emplacement.setParking(this);
        } else {
            throw new IllegalStateException("Parking is at full capacity.");
        }
    }
    */


}
